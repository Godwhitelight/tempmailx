## TempMailX
A python lib for reciving emails using 1secmail.com api.

---
### Example
```python
TODO: ADD HERE EXMPLE LMFAO
```