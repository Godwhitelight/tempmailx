import time
from src.tempmailx import TempMail

mail = TempMail()
print(mail.email)

while True:
    emails = mail.fetch_emails()
    print(emails)

    for email in emails:
        dat = email.fetch_data()
        print(dat['text'])
    time.sleep(5)
